exports.config = {
  headers: {
    "User-Agent": "axios app",
  },
};
exports.options = {
  borderStyle: "solid",
  borderColor: "blue",
  headerAlign: "center",
  align: "left",
  color: "white",
  truncate: "...",
  width: "90%",
};
